print("Hello Docker Project 06")
